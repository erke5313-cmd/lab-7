# Sneaker Store (Flutter)

Lab 7: multi-screen app with bottom navigation and detail screen.

## Features

- BottomNavigationBar with 3 tabs: Feed, Favorites, Profile
- Feed: list of products with image, title, category and price
- Favorites: items saved with the heart button (shared state in the root screen)
- Profile: simple user screen with a notifications switch
- Navigator.push opens DetailScreen and passes the full Product object
- Navigator.pop returns back (AppBar arrow and "Back to list" button)
- IndexedStack keeps tab state when switching tabs

## Folder structure

```
lib/
  main.dart
  models/product.dart
  data/products.dart
  screens/
    home_screen.dart
    feed_screen.dart
    favorites_screen.dart
    profile_screen.dart
    detail_screen.dart
  widgets/product_card.dart
```

## How to run

```
flutter pub get
flutter run
```
