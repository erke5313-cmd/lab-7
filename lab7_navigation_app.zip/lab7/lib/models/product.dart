// Simple data model for one product. The whole object is passed to DetailScreen.
class Product {
  final int id;
  final String title;
  final String description;
  final String imageUrl;
  final double price;
  final String category;

  const Product({
    required this.id,
    required this.title,
    required this.description,
    required this.imageUrl,
    required this.price,
    required this.category,
  });
}
