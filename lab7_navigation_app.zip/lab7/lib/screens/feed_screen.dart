import 'package:flutter/material.dart';
import '../models/product.dart';
import '../widgets/product_card.dart';

// Tab 1: list of all products
class FeedScreen extends StatelessWidget {
  final List<Product> products;
  final Set<int> favoriteIds;
  final void Function(int id) onToggleFavorite;

  const FeedScreen({
    super.key,
    required this.products,
    required this.favoriteIds,
    required this.onToggleFavorite,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sneaker Feed')),
      body: ListView.builder(
        padding: const EdgeInsets.symmetric(vertical: 8),
        itemCount: products.length,
        itemBuilder: (context, index) {
          final product = products[index];
          return ProductCard(
            product: product,
            isFavorite: favoriteIds.contains(product.id),
            onFavoriteToggle: () => onToggleFavorite(product.id),
          );
        },
      ),
    );
  }
}
