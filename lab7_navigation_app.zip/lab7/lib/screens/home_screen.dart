import 'package:flutter/material.dart';
import '../data/products.dart';
import 'favorites_screen.dart';
import 'feed_screen.dart';
import 'profile_screen.dart';

// Root screen: holds BottomNavigationBar and the shared favorites state
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;
  final Set<int> _favoriteIds = {};

  void _toggleFavorite(int id) {
    setState(() {
      if (_favoriteIds.contains(id)) {
        _favoriteIds.remove(id);
      } else {
        _favoriteIds.add(id);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final favoriteProducts =
        products.where((p) => _favoriteIds.contains(p.id)).toList();

    return Scaffold(
      // IndexedStack keeps every tab alive, so state is not lost on tab switch
      body: IndexedStack(
        index: _currentIndex,
        children: [
          FeedScreen(
            products: products,
            favoriteIds: _favoriteIds,
            onToggleFavorite: _toggleFavorite,
          ),
          FavoritesScreen(
            products: favoriteProducts,
            favoriteIds: _favoriteIds,
            onToggleFavorite: _toggleFavorite,
          ),
          ProfileScreen(favoritesCount: favoriteProducts.length),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Feed'),
          BottomNavigationBarItem(
              icon: Icon(Icons.favorite), label: 'Favorites'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}
