import '../models/product.dart';

// Hard coded list of products for the feed
const List<Product> products = [
  Product(
    id: 1,
    title: 'Air Runner Pro',
    description:
        'Lightweight running sneakers with a breathable mesh upper and a '
        'cushioned sole. Great for daily runs and long walks.',
    imageUrl:
        'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800',
    price: 129.99,
    category: 'Running',
  ),
  Product(
    id: 2,
    title: 'Street Classic',
    description:
        'Everyday casual sneakers with a clean look. Soft inner lining and '
        'a durable rubber outsole that goes with any outfit.',
    imageUrl:
        'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=800',
    price: 89.50,
    category: 'Casual',
  ),
  Product(
    id: 3,
    title: 'Court Master',
    description:
        'High support basketball shoes with extra ankle padding and strong '
        'grip for quick moves on the court.',
    imageUrl:
        'https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=800',
    price: 149.00,
    category: 'Basketball',
  ),
  Product(
    id: 4,
    title: 'Urban Flex',
    description:
        'Flexible and comfortable lifestyle sneakers for the city. Light '
        'weight design, easy to wear all day.',
    imageUrl:
        'https://images.unsplash.com/photo-1491553895911-0055eca6402d?w=800',
    price: 99.90,
    category: 'Lifestyle',
  ),
];
